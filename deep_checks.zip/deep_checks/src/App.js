
import { Box } from '@mui/system';
import './App.css';
import Sidebar from './components/sidebar/Sidebar';
import MyRouts from './routes';
import { Container } from '@mui/material'
import { BACKGROUND_COLOR_MAX_WIDTH } from './helpers/colors/color';
import { useEffect, useState } from 'react';

function getWindowSize() {
  const {innerWidth, innerHeight} = window;
  return {innerWidth, innerHeight};
}

function App() {
  const [windowSize, setWindowSize] = useState(getWindowSize());
  
  return ( <div className = "App" >
              <Box sx={{
                background:BACKGROUND_COLOR_MAX_WIDTH
              }}>
                <Container maxWidth={false} sx={{
                  maxWidth:"1920px",
                  minWidth: "1280px",
                }} >
                  <Box sx={{
                    display:"flex",
                    height:"100%"
                }}>
                    <Sidebar/>
                    <MyRouts />
                  </Box>
                </Container>
              </Box>
        </div>
    );
}

export default App;
