export const DASHBOARD = "/dashboard"
export const ALERTS = "/alerts"