export const BACKGROUND_COLOR_MAX_WIDTH = "linear-gradient(180deg, #F3F5F8 0%, #FFFFFF 29.64%, #FFFFFF 100%)"
export const SIDEBAR_COLOR = "#17003E"