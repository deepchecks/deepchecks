
import { ReactComponent as HomeIcon } from "./home.svg";
import { ReactComponent as Arow } from "./arow.svg";
import { ReactComponent as InfoIcon } from "./info.svg";
import { ReactComponent as PlusIcon } from "./plus.svg";
import { ReactComponent as SearchIcon } from "./search.svg";

export {
    HomeIcon,
    Arow,
    InfoIcon,
    PlusIcon,
    SearchIcon,
}