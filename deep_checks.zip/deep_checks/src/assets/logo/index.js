import { ReactComponent as Logo } from "./logo.svg";
import { ReactComponent as Logoin1280 } from "./logoin1280.svg";

export {
    Logo,
    Logoin1280
}